﻿namespace HR.Gateway.Infrastructure.Employee.Mapping;

public class AngajatiMapping
{
}