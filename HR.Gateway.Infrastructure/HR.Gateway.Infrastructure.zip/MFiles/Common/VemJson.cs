﻿namespace HR.Gateway.Infrastructure.MFiles.Common;

public class VemJson
{
    
}