﻿namespace HR.Gateway.Application.Models.Concedii;

public sealed class ConcediuPeAnDetaliat
{
    public required int An        { get; init; } 
    public required int AnId      { get; init; } 
    public required int Alocate   { get; init; }
    public required int Consumate { get; init; }
    public required int Ramase    { get; init; } 
}