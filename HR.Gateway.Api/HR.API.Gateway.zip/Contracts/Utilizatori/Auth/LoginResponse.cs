﻿namespace HR.Gateway.Api.Contracts.Utilizatori.Auth;

public class LoginResponse
{
    public required string Token { get; init; }
}