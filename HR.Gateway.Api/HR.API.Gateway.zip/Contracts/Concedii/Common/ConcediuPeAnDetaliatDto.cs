﻿namespace HR.Gateway.Api.Contracts.Concedii.Common;

public sealed class ConcediuPeAnDetaliatDto
{
    public int An { get; init; }
    public int AnId { get; init; }
    public int Alocate { get; set; }
    public int Consumate { get; set; }
    public int Ramase { get; set; }
}