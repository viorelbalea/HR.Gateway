﻿namespace HR.Gateway.Api.Contracts.Concedii.ConcediuOdihna;

public class AlocareZileLaCerereConcediuResponse
{
    public bool Success { get; init; }
    public string? Message { get; init; }
}