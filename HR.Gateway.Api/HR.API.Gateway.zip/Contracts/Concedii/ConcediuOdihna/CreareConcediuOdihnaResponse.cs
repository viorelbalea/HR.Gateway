﻿namespace HR.Gateway.Api.Contracts.Concedii.ConcediuOdihna;

public class CreareConcediuOdihnaResponse
{
    public bool Success { get; init; }
    public string? Message { get; init; }
    public int? CerereConcediuOdihnaId { get; init; }
}