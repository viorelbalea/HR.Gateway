﻿namespace HR.Gateway.Api.Contracts.Concedii.ConcediuOdihna;

public sealed class CereriConcediuOdihnaRequest
{
    public required string Email { get; set; }
}