﻿namespace HR.Gateway.Api.Contracts.Concedii.ConcediuOdihna;

public class AlocareZileLaCerereConcediuDto
{
    public int ConcediuPerAngajatId { get; init; }
    public int NumarZile { get; init; }
}